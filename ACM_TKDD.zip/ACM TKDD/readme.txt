This folder consists of multiple folders.

Code - consists all the code for the baselines and SIDR.
	1. Baselines - contains all the code for the different baselines implemented.
	2. AdjacencyGenerator.ipynb - contains code to create user-item interaction graph and user-user and user-item interaction graph.
	3. Implicit_Train_Test.ipynb - contains code to generate the pseudo unbiased test sets.
	4. Neighbor_Items.ipynb - contains the code to generate item sets from the user's neighborhood and to compute user's neighbor's popularity.
	5. SIDR-GCN.ipynb - contains the code for SIDR model based on LightGCN.
	6. AblationModel.ipynb - contains the code for RQ2. Ablation study.


Data - consists of 4 folders, 2 contains train data and other 2 contains test data for Epinions dataset.
	1. Epinions - contains the implicit ratings and implicit trust values for Epinions dataset.
	2. Epinions-TestSets - contains the pseudo unbiased test sets for evaluation for Epinions dataset.
	3. Ciao - contains the implicit ratings and implicit trust values for Ciao dataset.
	4. Ciao-TestSets - contains the pseudo unbiased test sets for evaluation for Ciao dataset.

Appendix.pdf -  contains the pdf for the appendix page.

All the code was written in google colab. To run the code, change the data path given in the python files to appropriate data paths and run it.


